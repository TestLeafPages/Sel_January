package testcases;

import org.testng.annotations.Test;

import pages.LoginPage;
import seleniumBase.ProjectSpecificMethods;

public class TC001_LoginLogout extends ProjectSpecificMethods {
	
	@Test
	public void loginLogout() {
		/*
		 * LoginPage lp = new LoginPage(); 
		 * lp.enterUsername(); 
		 * lp.enterPassword();
		 */
		
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLogin()
		.clickLogout();
	
	}
	
	
	
	
	
	
	
	
	
}
