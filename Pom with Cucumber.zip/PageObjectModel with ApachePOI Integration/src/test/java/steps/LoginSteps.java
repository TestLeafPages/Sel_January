/*
 * package steps;
 * 
 * import java.util.concurrent.TimeUnit;
 * 
 * import org.openqa.selenium.By; import
 * org.openqa.selenium.chrome.ChromeDriver;
 * 
 * import cucumber.api.java.en.Given; import cucumber.api.java.en.Then; import
 * cucumber.api.java.en.When;
 * 
 * public class LoginSteps { public ChromeDriver driver;
 * 
 * @Given("Open the Chrome Browser") public void openBrowser() {
 * System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
 * driver= new ChromeDriver(); }
 * 
 * @Given("Enter the url") public void enterURL() {
 * driver.get("http://leaftaps.com/opentaps"); }
 * 
 * @Given("Maximize the browser") public void maximiseBrowser() {
 * driver.manage().window().maximize(); }
 * 
 * @Given("Set the Timeouts") public void setTimeout() {
 * driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS); }
 * 
 * @Given("Enter the Username as (.*)") public void enterUsername(String data) {
 * driver.findElement(By.id("username")).sendKeys(data); }
 * 
 * @Given("Enter the Password as (.*)") public void enterPassword(String data) {
 * driver.findElement(By.id("password")).sendKeys(data); }
 * 
 * @When("Click on the Login Button") public void clickLogin() {
 * driver.findElement(By.className("decorativeSubmit")).click(); }
 * 
 * @Then("Verify Login is Successful") public void verifyLogin() {
 * System.out.println("Verify successful"); }
 * 
 * }
 */