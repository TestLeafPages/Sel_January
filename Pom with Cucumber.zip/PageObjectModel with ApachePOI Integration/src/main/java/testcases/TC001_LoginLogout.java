package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.LoginPage;
import seleniumBase.ProjectSpecificMethods;

public class TC001_LoginLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void setData() {
		excelFilename = "LoginLogout";
	}
	
	@Test(dataProvider = "fetchData")
	public void loginLogout(String userName, String password) {
		
		new LoginPage()
		.enterUsername(userName)
		.enterPassword(password)
		.clickLogin()
		.clickLogout();
		
		
		
		
		
		
		/*
		 * LoginPage lp = new LoginPage(); 
		 * lp.enterUsername(); 
		 * lp.enterPassword();
		 */
	
	}
	
	
	
	
	
	
	
	
	
}
