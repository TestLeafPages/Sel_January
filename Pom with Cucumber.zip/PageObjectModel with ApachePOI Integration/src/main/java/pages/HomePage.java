package pages;

import org.openqa.selenium.By;

import cucumber.api.java.en.Then;
import seleniumBase.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	@Then("Verify Login is Successful")
	public LoginPage clickLogout() {
		System.out.println(driver.findElement(By.tagName("h2")).getText());
		driver.findElementByClassName("decorativeSubmit").click();
		return new LoginPage();
	}
	
	
	
	
	
	
	

}
