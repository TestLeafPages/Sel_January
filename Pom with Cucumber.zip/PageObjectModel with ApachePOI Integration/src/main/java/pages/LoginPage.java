package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import seleniumBase.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = "username")
	WebElement eleUserName;
	@Given("Enter the Username as (.*)")
	public LoginPage enterUsername(String data) {
		eleUserName.sendKeys(data);
		return this;
	}

	@FindBy(how = How.ID, using = "password")
	WebElement elePass;
	@Given("Enter the Password as (.*)")
	public LoginPage enterPassword(String data) {
		elePass.sendKeys(data);
		return this;
	}
	@When("Click on the Login Button")
	public HomePage clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePage();
	}

}
